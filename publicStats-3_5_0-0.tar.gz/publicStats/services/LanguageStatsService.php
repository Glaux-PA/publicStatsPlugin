<?php

/**
 * @file plugins/generic/publicStats/services/LanguageStatsService.php
 *
 * Copyright (c) 2026 Universitat Rovira i Virgili
 * Copyright (c) 2026 Glaux Publicaciones Académicas, S.L.
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @class LanguageStatsService
 * @ingroup plugins_generic_publicStats
 *
 * @brief Service for language distribution statistics of published articles.
 *
 * Counts published articles by language. An article available in multiple
 * locales is counted once per language (normalised: es_ES and es_MX both
 * collapse to es). Language names are returned in the current UI locale.
 */

declare(strict_types=1);

namespace APP\plugins\generic\publicStats\services;

use Illuminate\Support\Facades\DB;
use PKP\facades\Locale;
use PKP\submission\PKPSubmission;

class LanguageStatsService
{
    /**
     * Get article counts grouped by language.
     *
     * Determines languages from publication_galleys. An article with galleys
     * in two locales is counted in both language categories.
     *
     * @param int $contextId
     * @param int|null $issueId Null = all published issues
     * @return array [['code' => 'es', 'name' => 'Español', 'count' => 42], ...]
     */
    public function getLanguageStats(int $contextId, ?int $issueId = null): array
    {
        $query = DB::table('publications as p')
            ->join('publication_galleys as pg', function ($join) {
                $join->on('pg.publication_id', '=', 'p.publication_id')
                    ->whereNotNull('pg.locale')
                    ->where('pg.locale', '!=', '');
            })
            ->join('submissions as s', function ($join) use ($contextId) {
                $join->on('s.submission_id', '=', 'p.submission_id')
                    ->where('s.context_id', '=', $contextId)
                    ->where('s.status', '=', PKPSubmission::STATUS_PUBLISHED);
            })
            ->where('p.status', '=', PKPSubmission::STATUS_PUBLISHED)
            ->select('pg.locale', DB::raw('COUNT(DISTINCT p.submission_id) as article_count'))
            ->groupBy('pg.locale');

        if ($issueId !== null) {
            $query->where('p.issue_id', '=', $issueId);
        }

        $rows = $query->orderByDesc('article_count')->get();

        $uiLocale = Locale::getLocale();

        // Normalize locale variants to primary language (es_ES + es_MX => es).
        $merged = [];
        foreach ($rows as $row) {
            $langCode = \Locale::getPrimaryLanguage($row->locale) ?: $row->locale;
            if (!isset($merged[$langCode])) {
                $displayName = \Locale::getDisplayLanguage($row->locale, $uiLocale);
                $name = $displayName
                    ? mb_strtoupper(mb_substr($displayName, 0, 1)) . mb_substr($displayName, 1)
                    : $langCode;
                $merged[$langCode] = ['code' => $langCode, 'name' => $name, 'count' => 0];
            }
            $merged[$langCode]['count'] += (int) $row->article_count;
        }

        usort($merged, fn($a, $b) => $b['count'] - $a['count']);

        return array_values($merged);
    }

    /**
     * Get article counts per language grouped by year of publication.
     *
     * Determines languages from publication_galleys. Articles with galleys in
     * multiple locales are counted in each. Articles not assigned to a
     * published issue are excluded (no reliable publish date).
     *
     * @param int $contextId
     * @return array { labels: string[], series: [{code, name, data: int[]}] }
     */
    public function getLanguageTrends(int $contextId): array
    {
        // MySQL: YEAR(). PostgreSQL: EXTRACT.
        $driver = DB::connection()->getDriverName();
        $isPgsql = $driver === 'pgsql';
        $yearExpr  = $isPgsql
            ? 'EXTRACT(YEAR FROM i.date_published)::integer'
            : 'YEAR(i.date_published)';

        $rows = DB::table('publications as p')
            ->join('publication_galleys as pg', function ($join) {
                $join->on('pg.publication_id', '=', 'p.publication_id')
                    ->whereNotNull('pg.locale')
                    ->where('pg.locale', '!=', '');
            })
            ->join('submissions as s', function ($join) use ($contextId) {
                $join->on('s.submission_id', '=', 'p.submission_id')
                    ->where('s.context_id', '=', $contextId)
                    ->where('s.status', '=', PKPSubmission::STATUS_PUBLISHED);
            })
            ->join('issues as i', function ($join) {
                $join->on('i.issue_id', '=', 'p.issue_id')
                    ->where('i.published', '=', 1);
            })
            ->where('p.status', '=', PKPSubmission::STATUS_PUBLISHED)
            ->whereNotNull('i.date_published')
            ->select(
                'pg.locale',
                DB::raw("{$yearExpr} as pub_year"),
                DB::raw('COUNT(DISTINCT p.submission_id) as article_count')
            )
            ->groupBy('pg.locale', DB::raw($yearExpr))
            ->orderBy(DB::raw($yearExpr))
            ->get();

        if ($rows->isEmpty()) {
            return ['labels' => [], 'series' => []];
        }

        $uiLocale = Locale::getLocale();
        $yearLangMap = [];
        $langNames = [];

        foreach ($rows as $row) {
            $langCode = \Locale::getPrimaryLanguage($row->locale) ?: $row->locale;
            $year = (string)$row->pub_year;

            $yearLangMap[$year][$langCode] = ($yearLangMap[$year][$langCode] ?? 0) + (int)$row->article_count;

            if (!isset($langNames[$langCode])) {
                $displayName = \Locale::getDisplayLanguage($row->locale, $uiLocale);
                $langNames[$langCode] = $displayName
                    ? mb_strtoupper(mb_substr($displayName, 0, 1)) . mb_substr($displayName, 1)
                    : $langCode;
            }
        }

        $allYears = array_keys($yearLangMap);
        sort($allYears);

        $langTotals = [];
        foreach ($yearLangMap as $yearData) {
            foreach ($yearData as $code => $count) {
                $langTotals[$code] = ($langTotals[$code] ?? 0) + $count;
            }
        }
        arsort($langTotals);
        $orderedCodes = array_keys($langTotals);

        $series = [];
        foreach ($orderedCodes as $code) {
            $data = [];
            foreach ($allYears as $year) {
                $data[] = $yearLangMap[$year][$code] ?? 0;
            }
            $series[] = [
                'code' => $code,
                'name' => $langNames[$code] ?? $code,
                'data' => $data,
            ];
        }

        return ['labels' => $allYears, 'series' => $series];
    }

    /**
     * Get published issues ordered by date desc for the filter dropdown.
     *
     * @param int $contextId
     * @return array [['id' => 5, 'label' => 'Vol. 12 No. 2 (2024)'], ...]
     */
    public function getPublishedIssues(int $contextId): array
    {
        $rows = DB::table('issues')
            ->where('journal_id', '=', $contextId)
            ->where('published', '=', 1)
            ->orderByDesc('date_published')
            ->select('issue_id', 'volume', 'number', 'year', 'show_volume', 'show_number', 'show_year', 'show_title')
            ->get();

        $result = [];
        foreach ($rows as $row) {
            $result[] = ['id' => $row->issue_id, 'label' => $this->buildIssueLabel($row)];
        }

        return $result;
    }

    private function buildIssueLabel(object $issue): string
    {
        $parts = [];
        if ($issue->show_volume && $issue->volume) {
            $parts[] = __('issue.vol') . ' ' . $issue->volume;
        }
        if ($issue->show_number && $issue->number) {
            $parts[] = __('issue.no') . ' ' . $issue->number;
        }
        if ($issue->show_year && $issue->year) {
            $parts[] = '(' . $issue->year . ')';
        }
        if (!empty($parts)) {
            return implode(' ', $parts);
        }

        // Fallback: use the issue title from settings.
        $title = DB::table('issue_settings')
            ->where('issue_id', '=', $issue->issue_id)
            ->where('setting_name', '=', 'title')
            ->value('setting_value');

        return $title ?: '#' . $issue->issue_id;
    }
}
